public class Road {
  public String name;
  public Crossroad start;
  public Crossroad end;

  public boolean isFree(int position) {
    return false;
  }
}
