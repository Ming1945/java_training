public class Crossroad {
  public String name;
}
