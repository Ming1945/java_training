class Car {
  public String name;
  public Road road;
  public int position;

  public void update() {
    if (road.isFree(position + 1)) {
      road.free(position);
      position = position + 1;
      road.occupy(position);
    }
  }
}
