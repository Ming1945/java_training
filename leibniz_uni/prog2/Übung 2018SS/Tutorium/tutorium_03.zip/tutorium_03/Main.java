public class Main {
  public static void main(String[] args) {
    Crossroad a = new Crossroad();
    a.name = "A";
    Crossroad b = new Crossroad();
    b.name = "B";

    Road aToB = new Road();
    aToB.name = "A -> B";
    aToB.start = a;
    aToB.end = b;

    Car c = new Car();
    c.name = "C1";
    c.road = aToB;
    c.position = 0;
  }
}
