public class Simulation {
  public Car[] cars = new Car[10];

  public void run() {
    // until simulation terminates:
    while (??) {
    //  increase total elapsed time counter by 1.

    //  for each car in the system:
    for (int i = 0; i < cars.length; i++) {
      if (cars[i] == null) continue;
    //    update car state.
      cars[i].update();
    }
  }
}
