package de.uni_hannover.sim.madn.model;

public class Figure {
  public BoardTile tile;

  public boolean isInPlay() {
    return tile != null;
  }
}
