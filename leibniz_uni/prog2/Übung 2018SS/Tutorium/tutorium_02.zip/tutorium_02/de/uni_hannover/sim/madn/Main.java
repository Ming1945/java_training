package de.uni_hannover.sim.madn;

import de.uni_hannover.sim.madn.model.Game;

public class Main {
  public static void main(String[] args) {
    Game game = new Game();
    game.play();
  }
}
