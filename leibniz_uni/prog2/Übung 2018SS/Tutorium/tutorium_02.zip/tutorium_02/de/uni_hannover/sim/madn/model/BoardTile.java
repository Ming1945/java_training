package de.uni_hannover.sim.madn.model;

public class BoardTile {
  BoardTile next;
  BoardTile winTile;
  Player winTileOwner;

  public BoardTile getNext(int distance) {
    if (distance == 1) {
      return next;
    } else {
      return next.getNext(distance - 1);
    }
  }
}
