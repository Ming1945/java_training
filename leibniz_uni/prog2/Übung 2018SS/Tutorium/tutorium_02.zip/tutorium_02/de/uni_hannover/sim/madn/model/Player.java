package de.uni_hannover.sim.madn.model;

import java.util.Random;

public class Player {
  public final String name;
  public final Figure figure;
  public final Random random;
  public BoardTile startTile;

  public Player(String n) {
    name = n;
    figure = new Figure();
    random = new Random();
  }

  public void takeTurn() {
    final int diceRoll = random.nextInt(6) + 1;
    if (figure.isInPlay()) {
      figure.tile = figure.tile.getNext(diceRoll);
    } else if (diceRoll == 6) {
      figure.tile = startTile;
    }
  }

  public boolean hasWon() {
    return false;
  }
}
