package de.uni_hannover.sim.madn.model;

public class Game {
  final Player[] players;

  public Game() {
    players = new Player[2];
    players[0] = new Player("Player 1");
    players[1] = new Player("Player 2");

    BoardTile first = new BoardTile();
    BoardTile last = first;
    for (int i = 0; i < 39; i++) {
      BoardTile current = new BoardTile();
      last.next = current;
      last = current;
    }
    last.next = first;

    players[0].startTile = first;
    players[1].startTile = first.getNext(20);
  }

  public void play() {
    while (!isOver()) {
      for (int i = 0; i < players.length; i++) {
        players[i].takeTurn();
      }
    }

    for (int i = 0; i < players.length; i++) {
      if (players[i].hasWon()) {
        System.out.println(players[i].name + " has won!");
      }
    }
  }

  public boolean isOver() {
    for (int i = 0; i < players.length; i++) {
      if (players[i].hasWon()) {
        return true;
      }
    }
    return false;
  }
}
