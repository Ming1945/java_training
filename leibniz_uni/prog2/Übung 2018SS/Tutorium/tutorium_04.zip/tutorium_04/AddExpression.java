public class AddExpression extends BinaryExpression {
  public AddExpression(Expression leftOperand, Expression rightOperand) {
    super(leftOperand, rightOperand);
  }

  @Override
  public int evaluate() {
    return leftOperand.evaluate() + rightOperand.evaluate();
  }

  public String getOperatorString() {
    return "+";
  }
}
