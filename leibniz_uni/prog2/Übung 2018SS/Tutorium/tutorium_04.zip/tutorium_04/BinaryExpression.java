public abstract class BinaryExpression extends Expression {
  final Expression leftOperand;
  final Expression rightOperand;

  public BinaryExpression(Expression leftOperand, Expression rightOperand) {
    this.leftOperand = leftOperand;
    this.rightOperand = rightOperand;
  }

  abstract String getOperatorString();

  public String toString() {
    return leftOperand.toString() + getOperatorString() + rightOperand.toString();
  }
}
