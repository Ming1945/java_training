public class MultiplyExpression extends BinaryExpression {

  public MultiplyExpression(Expression leftOperand, Expression rightOperand) {
    super(leftOperand, rightOperand);
  }

  public int evaluate() {
    return leftOperand.evaluate() * rightOperand.evaluate();
  }

  String getOperatorString() {
    return "*";
  }
}
