public class LiteralExpression extends Expression {
  final int value;

  LiteralExpression(int value) {
    this.value = value;
  }

  public int evaluate() {
    return value;
  }

  public String toString() {
    return String.valueOf(value);
  }
}
