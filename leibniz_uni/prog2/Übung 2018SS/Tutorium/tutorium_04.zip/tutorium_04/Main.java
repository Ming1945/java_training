public class Main {
  public static void main(String[] args) {
    Expression e1 = new FunctionCallExpression();
    System.out.println(e1.toString() + " = " + e1.evaluate());
  }
}
