public class FunctionCallExpression extends Expression {
  public String toString() {
    return "f()";
  }
}
