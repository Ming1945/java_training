package de.uni_hannover.sim.exemplary_solution.profiling;

public interface DataSource {
  /**
   * If nextFreeIndex points past the end of log, allocates a new array with twice
   * the size of log and copies the contents of log to the new array. Returns the
   * array that should be used from now on.
   */
  static double[] resizeIfFull(double[] log, int nextFreeIndex) {
    if (nextFreeIndex < log.length - 1)
      return log;
    double[] copy = new double[log.length * 2];
    for (int i = 0; i < nextFreeIndex; i++) {
      copy[i] = log[i];
    }
    return copy;
  }

  /**
   * Creates a copy of the used part of log and returns it.
   */
  static double[] copyFirstElements(double[] log, int nextFreeIndex) {
    double[] copy = new double[nextFreeIndex];
    for (int i = 0; i < nextFreeIndex; i++) {
      copy[i] = log[i];
    }
    return copy;
  }

  /**
   * Returns the name of this object, which can be an arbitrary string. However,
   * the name must be unique in a simulation because it is used to identify this
   * object.
   */
  public String getName();

  /**
   * Instructs this object to write an entry to its internal log.
   */
  public void logStatus();

  /**
   * Returns a copy of the internal log. Does NOT return a reference to the
   * internal log because then other code could write to that log.
   */
  public double[] getLog();

  /**
   * Returns a string representation of the current status of this object.
   *
   * @return An arbitrary formatted string for use in the CLI status/debugging
   *         log.
   */
  public String reportStatus();

  public Object clone(Object[][] alreadyCloned);
}
