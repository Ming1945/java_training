package de.uni_hannover.sim.exemplary_solution.model;

import de.uni_hannover.sim.exemplary_solution.simulation.Simulation;

/**
 * Represents an outermost point in the viewport on the simulated world; that
 * is, there exists a world beyond this point, but this program doesn't simulate
 * it. Therefore, cars can go "into view" or "out of view" at here.
 *
 * A world boundary has a {@code spawn probability} that indicates how often
 * cars arrive in the simulated system at this crossroads. Every time step, a
 * world boundary adds a new car to the system with this probability.
 */
public class WorldBoundary extends Crossroads implements Cloneable {
  static final int MAX_ROUTES = 6;

  /**
   * A value between 0 and 1; 0 means cars never spawn here, 1 means a new car is
   * spawned in every single time step.
   */
  protected final double spawnProbability;

  /**
   * The possible routes a car can take if it arrives in the system through this
   * world boundary.
   */
  protected RouteSegment[] routes;

  /**
   * The random number that was selected during the last {@code update} call.
   */
  protected double lastRandomNumber;

  /**
   * Partially initializes the world boundary and adds it to the simulation.
   *
   * Warning: To complete the initialization, use {@code addRoute} for each route.
   * This number must match the {@code routeCount} parameter.
   */
  public WorldBoundary(Simulation simulation, String name, double spawnProbability, int routeCount) {
    super(simulation, name);
    this.spawnProbability = spawnProbability;
    this.routes = new RouteSegment[routeCount];
  }

  public void addRoute(RouteSegment route) {
    for (int i = 0; i < routes.length; i++) {
      if (routes[i] == null) {
        routes[i] = route;
        return;
      }
    }
  }

  /**
   * In {@code spawnProbability} percent of the calls, selects a random route from
   * {@code routes}. If position 0 on the first road of that route is free, create
   * a new car with that route.
   */
  @Override
  public void update() {

    if ((lastRandomNumber = simulation.getRng().nextDouble()) >= spawnProbability) {
      return;
    }

    RouteSegment route = routes[simulation.getRng().nextInt(routes.length)];
    if (!route.crossroads.getRoadTo(route.next.crossroads).isFree(0)) {
      return;
    }

    new Car(simulation, Integer.toHexString(simulation.getRng().nextInt()), route);
  }

  public WorldBoundary clone(Object[][] alreadyCloned) {
    WorldBoundary clone = null;
    {
      int i;
      for (i = 0; i < alreadyCloned.length && alreadyCloned[i][0] != null; i++) {
        if (alreadyCloned[i][0] == this) {
          return (WorldBoundary) alreadyCloned[i][1];
        }
      }
      if (i == alreadyCloned.length) {
        throw new IllegalStateException("alreadyCloned array too small");
      }
      alreadyCloned[i][0] = this;
      try {
        alreadyCloned[i][1] = clone = (WorldBoundary) super.clone();
      } catch (CloneNotSupportedException e) {
        assert false;
      }
    }

    clone.simulation = (Simulation) alreadyCloned[0][1];
    clone.startingRoads = new Road[startingRoads.length];
    for (int i = 0; i < startingRoads.length; i++) {
      if (startingRoads[i] != null)
        clone.startingRoads[i] = startingRoads[i].clone(alreadyCloned);
    }
    clone.endingRoads = new Road[endingRoads.length];
    for (int i = 0; i < endingRoads.length; i++) {
      if (endingRoads[i] != null)
        clone.endingRoads[i] = endingRoads[i].clone(alreadyCloned);
    }
    clone.routes = routes.clone();
    for (int i = 0; i < routes.length; i++) {
      if (routes[i] != null)
        clone.routes[i] = routes[i].clone(alreadyCloned);
    }

    return clone;
  }
}
