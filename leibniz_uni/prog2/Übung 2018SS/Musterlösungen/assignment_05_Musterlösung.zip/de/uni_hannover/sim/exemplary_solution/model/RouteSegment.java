package de.uni_hannover.sim.exemplary_solution.model;

/**
 * A <a href="https://en.wikipedia.org/wiki/Linked_list">linked list</a> that
 * represents a route that a car takes through the road system. Each
 * {@code RouteSegment} object stores a single intermediate destination, and a
 * reference to the next segment.
 *
 * The first crossroads in a route is the starting point of the car; The car
 * spawns on position 0 of the road that connects the first two segments. The
 * last segment represents the final destination of the car. The car arrives at
 * the destination if it stands on the last position of the road that ends at
 * that crossroad.
 *
 * RouteSegment objects are immutable, so they can be reused and shared between
 * objects without risk.
 */
public class RouteSegment implements Cloneable {
  protected final Crossroads crossroads;
  protected final RouteSegment next;

  public Crossroads getCrossroads() {
    return crossroads;
  }

  public RouteSegment getNext() {
    return next;
  }

  public RouteSegment(Crossroads crossroads, RouteSegment next) {
    this.crossroads = crossroads;
    this.next = next;
  }

  public RouteSegment(Crossroads crossroads) {
    this(crossroads, null);
  }

  public RouteSegment clone(Object[][] alreadyCloned) {
    int i;
    for (i = 0; i < alreadyCloned.length && alreadyCloned[i][0] != null; i++) {
      if (alreadyCloned[i][0] == this) {
        return (RouteSegment) alreadyCloned[i][1];
      }
    }
    if (i == alreadyCloned.length) {
      throw new IllegalStateException("alreadyCloned array too small");
    }

    RouteSegment clone = next == null ? new RouteSegment(crossroads.clone(alreadyCloned))
        : new RouteSegment(crossroads.clone(alreadyCloned), next.clone(alreadyCloned));

    alreadyCloned[i][0] = this;
    alreadyCloned[i][1] = clone;
    return clone;
  }
}
