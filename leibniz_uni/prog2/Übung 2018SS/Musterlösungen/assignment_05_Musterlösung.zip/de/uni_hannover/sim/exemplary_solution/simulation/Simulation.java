package de.uni_hannover.sim.exemplary_solution.simulation;

import java.util.Random;
import de.uni_hannover.sim.exemplary_solution.model.*;
import de.uni_hannover.sim.exemplary_solution.profiling.*;

/**
 * An object of type simulation stores a model of the simulated world, as well
 * as references to all {@code Actor}s. Instantiating a simulation will
 * initialize it with a road system. You can then call {@code update} on it to
 * advance its simulated time.
 */
public class Simulation implements Cloneable {
  /**
   * The maximum number of actors that are expected to ever be in the simulation
   * simultaneously. Any more actors beyond this number will be silently
   * discarded.
   */
  protected static final int MAX_ACTORS = 100;
  public static final int MAX_DATA_SOURCES = 100;

  /**
   * The random number generator that is shared across all actors of this
   * simulation.
   */
  protected Random rng;

  public Random getRng() {
    return rng;
  }

  public void setRng(Random rng) {
    this.rng = rng;
  }

  /**
   * A list of all actors that are currently active in the system. May contain
   * null indexes.
   */
  protected Actor[] actors;

  protected DataSource[] dataSources;

  /**
   * All cars that have left the system and are no longer in {@code actors}.
   */
  protected Car[] arrivedCars;

  /**
   * The names of the DataSource objects that should be protocolled in this run.
   */
  protected final String[] dataSourceNames;

  /**
   * If this is true, then all cars should be treated as if their names were
   * present in dataSourceNames.
   */
  protected boolean profileCars;

  /**
   * Initializes this simulation object with the fixed road system:
   *
   * <ul>
   * <li>{@code WorldBoundary} <i>A</i> with a spawn probability of 20%.</li>
   * <li>{@code WorldBoundary} <i>B</i> with a spawn probability of 30%.</li>
   * <li>{@code TimerControlledTrafficLightCrossroads} <i>C</i> with two
   * greenlight phases, each with a duration of 4 time steps.</li>
   * <li>{@code WorldBoundary} <i>D</i> with a spawn probability of 0%.</li>
   * <li>{@code WorldBoundary} <i>E</i> with a spawn probability of 0%.</li>
   * <li>A road from <i>A</i> to <i>C</i> with length 7 that is greenlighted on
   * phase 0.</li>
   * <li>A road from <i>B</i> to <i>C</i> with length 4 that is greenlighted on
   * phase 1.</li>
   * <li>A road from <i>C</i> to <i>D</i> with length 5.</li>
   * <li>A road from <i>C</i> to <i>E</i> with length 3.</li>
   * </ul>
   */
  public Simulation(Random rng, String[] dataSourceNames, boolean profileCars) {
    this.rng = rng;
    this.dataSourceNames = dataSourceNames;
    this.profileCars = profileCars;

    actors = new Actor[MAX_ACTORS];
    dataSources = new DataSource[MAX_DATA_SOURCES];
    arrivedCars = new Car[MAX_ACTORS];

    WorldBoundary a = new WorldBoundary(this, "A", 0.2, 2);
    WorldBoundary b = new WorldBoundary(this, "B", 0.3, 2);
    Crossroads c = new TimerControlledTrafficLightCrossroads(this, "C", new int[] { 4, 4 });
    WorldBoundary d = new WorldBoundary(this, "D", 0.0, 0);
    WorldBoundary e = new WorldBoundary(this, "E", 0.0, 0);

    addDataSource(new Road(a, c, 7, 0));
    addDataSource(new Road(b, c, 4, 1));
    addDataSource(new Road(c, d, 5));
    addDataSource(new Road(c, e, 3));

    a.addRoute(new RouteSegment(a, new RouteSegment(c, new RouteSegment(d))));
    a.addRoute(new RouteSegment(a, new RouteSegment(c, new RouteSegment(e))));
    b.addRoute(new RouteSegment(b, new RouteSegment(c, new RouteSegment(d))));
    b.addRoute(new RouteSegment(b, new RouteSegment(c, new RouteSegment(e))));
  }

  /**
   * Advances the simulation time by {@code iterations} time steps, and reports
   * the current status of all actors in each step. This method may be called
   * multiple times on the same simulation object.
   */
  public void run(final int iterations, final boolean isTransientPhase) {
    // Back up this value and restore it afterwards. This way, cars that enter the
    // simulation world during the settling time won't be added to {@code
    // dataSouces}.
    boolean profileCars = this.profileCars;
    this.profileCars = isTransientPhase;

    for (int elapsedTime = 0; elapsedTime < iterations; elapsedTime++) {
      for (int i = 0; i < actors.length; i++) {
        if (actors[i] != null) {
          actors[i].update();
        }
      }

      if (!isTransientPhase) {
        for (int i = 0; i < dataSources.length; i++) {
          if (dataSources[i] != null) {
            dataSources[i].logStatus();
            System.out.println(dataSources[i].getName() + ": " + dataSources[i].reportStatus());
          }
        }
      }
    }

    this.profileCars = profileCars;
  }

  /**
   * Prints the logs of all {@Code DataSource}s to {@code System.out}.
   */
  public void report() {
    for (int i = 0; i < dataSources.length; i++) {
      if (dataSources[i] != null) {
        System.out.println(dataSources[i].getName() + ": mean of " + Statistics.calculateMean(dataSources[i].getLog()));
      }
    }
    if (profileCars) {
      int count = 0;
      while (arrivedCars[count] != null) {
        count++;
      }
      double[] allTravelSpeeds = new double[count];
      for (int i = 0; i < count; i++) {
        allTravelSpeeds[i] = Statistics.calculateMean(arrivedCars[i].getLog());
      }
      System.out.println("Average travel speed: " + Statistics.calculateMean(allTravelSpeeds));
    }
  }

  /**
   * Registers {@code actor} as an active actor in the simulation. When this
   * method is called during a {@code Simulation.run} iteration, it is unspecified
   * whether the actor will be updated in the current iteration or not.
   *
   * If {@code MAX_ACTORS} are already in this simulation, this method will throw
   * an {@code IllegalStateError}. TODO: Use a {@code java.util.ArrayList} instead
   * to avoid this problem.
   *
   * This method may only be called by the {@code Actor} constructor!
   */
  public void addActor(Actor actor) {
    boolean successful = false;
    for (int i = 0; i < actors.length; i++) {
      if (actors[i] == null) {
        actors[i] = actor;
        successful = true;
        break;
      }
    }
    if (!successful) {
      throw new IllegalStateException("Capacity of `actors` exceeded");
    }

    if (actor instanceof DataSource) {
      addDataSource((DataSource) actor);
    }
  }

  /**
   * Removes {@code Actor} from the list of active actors. It will not be updated
   * anymore.
   */
  public void removeActor(Actor actor) {
    for (int i = 0; i < actors.length; i++) {
      if (actors[i] == actor) {
        actors[i] = null;
        break;
      }
    }

    if (actor instanceof DataSource) {
      ((DataSource) actor).logStatus();
      for (int i = 0; i < dataSources.length; i++) {
        if (dataSources[i] == actor) {
          dataSources[i] = null;
          break;
        }
      }
    }

    if (actor instanceof Car && profileCars) {
      for (int i = 0; i < arrivedCars.length; i++) {
        if (arrivedCars[i] == null) {
          arrivedCars[i] = (Car) actor;
          break;
        }
      }
    }
  }

  /**
   * Adds dataSource to the array of data sources that log their status every time
   * step, if the name of that object is in the list of data sources that should
   * be logged.
   */
  void addDataSource(DataSource dataSource) {
    if (dataSource instanceof Car) {
      if (!profileCars)
        return;
    } else {
      boolean shouldBeLogged = false;
      for (int i = 0; i < dataSourceNames.length && dataSourceNames[i] != null; i++) {
        if (dataSource.getName().equals(dataSourceNames[i])) {
          shouldBeLogged = true;
          break;
        }
      }
      if (!shouldBeLogged)
        return;
    }

    for (int j = 0; j < dataSources.length; j++) {
      if (dataSources[j] == null) {
        dataSources[j] = dataSource;
        break;
      }
    }
  }

  @Override
  public Simulation clone() {
    Simulation clone = null;
    try {
      clone = (Simulation) super.clone();
    } catch (CloneNotSupportedException e) {
      assert false : "This never happens because this class implements Cloneable";
    }
    // This is just plain wrong, but as it turns out, Random is not cloneable.
    clone.rng = new Random();
    clone.actors = new Actor[actors.length];
    clone.dataSources = new DataSource[dataSources.length];
    clone.arrivedCars = new Car[arrivedCars.length];
    // DON'T copy profileCars (because it's a boolean) and dataSourceNames (because
    // it's a variable that is only read, but never written, so it doesn't matter
    // if it's shared between multiple objects)

    // TODO: Use a {@code Map} here.
    Object[][] mapping = new Object[MAX_ACTORS * 4][2];
    mapping[0][0] = this;
    mapping[0][1] = clone;

    for (int i = 0; i < actors.length; i++) {
      if (actors[i] != null)
        clone.actors[i] = (Actor) actors[i].clone(mapping);
    }
    for (int i = 0; i < dataSources.length; i++) {
      if (dataSources[i] != null)
        clone.dataSources[i] = (DataSource) dataSources[i].clone(mapping);
    }
    for (int i = 0; i < arrivedCars.length; i++) {
      if (arrivedCars[i] != null)
        clone.arrivedCars[i] = arrivedCars[i].clone(mapping);
    }

    return clone;
  }
}
