package de.uni_hannover.sim.exemplary_solution.model;

import de.uni_hannover.sim.exemplary_solution.profiling.DataSource;

/**
 * A road connects two crossroads. Cars can drive on it, but only in one
 * direction: From {@code start} to {@code end}. If you need to drive in the
 * other direction, add a separate road object where start and end are switched.
 *
 * A road consists of a number of slots. Each slot has place for one car. Cars
 * can communicate their current position between each other by occupying slots
 * on the road; if another car is on the same road, it can avoid a collision by
 * checking whether the desired slot is free.
 */
public class Road implements DataSource, Cloneable {
  /**
   * The starting point of this road.
   */
  protected Crossroads start;

  /**
   * The destination of this road.
   */
  protected Crossroads end;

  /**
   * The slots on this road. {@code true} means the slot is currently occupied.
   */
  protected boolean[] slots;

  /**
   * If {@code end} is a traffic light, and its current greenlight phase equals
   * this value, then this road is greenlighted.
   */
  protected int greenlightPase;

  /**
   * The log for the DataSource interface.
   */
  protected double[] log = new double[8];
  protected int nextFreeLogIndex = 0;

  /**
   * Initializes a road that does not lead to a traffic light crossroads.
   */
  public Road(Crossroads start, Crossroads end, int length) {
    this(start, end, length, -1);
  }

  public String getName() {
    return start.name + "->" + end.name;
  }

  /**
   * Initialies a road whose {@code end} is a traffic light. This road is
   * greenlighted as long as {@code end} is in the same phase as
   * {@code greenlightPhase}.
   */
  public Road(Crossroads start, Crossroads end, int length, int greenlightPase) {
    slots = new boolean[length];

    this.start = start;
    this.end = end;
    start.addRoad(this);
    end.addRoad(this);

    assert greenlightPase == -1
        || end instanceof TimerControlledTrafficLightCrossroads : "Can't assign a greenlight phase to a road "
            + "if it doesn't end at a traffic light";
    this.greenlightPase = greenlightPase;
  }

  /**
   * Returns the number of slots on this road.
   */
  public int getLength() {
    return slots.length;
  }

  /**
   * Marks {@code slot} as occupied by a car. Fails if the position is already
   * occupied.
   */
  public void occupy(int slot) {
    assert !slots[slot] : "Already occupied";
    slots[slot] = true;
  }

  /**
   * Marks {@code slot} as no longer occupied. Fails if the position was already
   * free before.
   */
  public void leave(int slot) {
    assert slots[slot] : "Already free";
    slots[slot] = false;
  }

  /**
   * Indicates whether {@code slot} is free or occupied.
   *
   * @return {@code true} if the slot is free, {@code false} if the slot is
   *         occupied.
   */
  public boolean isFree(int slot) {
    return !slots[slot];
  }

  @Override
  public void logStatus() {
    int totalOccupiedSlots = 0;
    for (int i = 0; i < slots.length; i++) {
      if (!isFree(i))
        totalOccupiedSlots++;
    }
    log = DataSource.resizeIfFull(log, nextFreeLogIndex);
    log[nextFreeLogIndex++] = totalOccupiedSlots;
  }

  @Override
  public double[] getLog() {
    return DataSource.copyFirstElements(log, nextFreeLogIndex);
  }

  @Override
  public String reportStatus() {
    String report = "";
    for (int i = 0; i < slots.length; i++) {
      if (isFree(i)) {
        report += ' ';
      } else {
        report += 'X';
      }
      if (i != slots.length - 1) {
        report += " | ";
      }
    }
    return report;
  }

  public Road clone(Object[][] alreadyCloned) {
    Road clone = null;
    {
      int i;
      for (i = 0; i < alreadyCloned.length && alreadyCloned[i][0] != null; i++) {
        if (alreadyCloned[i][0] == this) {
          return (Road) alreadyCloned[i][1];
        }
      }
      if (i == alreadyCloned.length) {
        throw new IllegalStateException("alreadyCloned array too small");
      }
      alreadyCloned[i][0] = this;
      try {
        alreadyCloned[i][1] = clone = (Road) super.clone();
      } catch (CloneNotSupportedException e) {
        assert false;
      }
    }

    clone.start = start.clone(alreadyCloned);
    clone.end = end.clone(alreadyCloned);
    clone.slots = slots.clone();
    clone.log = log.clone();
    return clone;
  }
}
