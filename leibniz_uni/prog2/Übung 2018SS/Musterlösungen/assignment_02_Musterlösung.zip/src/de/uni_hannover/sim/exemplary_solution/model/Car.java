package de.uni_hannover.sim.exemplary_solution.model;

import de.uni_hannover.sim.exemplary_solution.simulation.Simulation;

/**
 * TODO: Document me!
 */
public class Car {
  /**
   * TODO: Document me!
   */
  final Simulation simulation;
  public final String name;

  /**
   * TODO: Document me!
   */
  public Road road;

  /**
   * TODO: Document me!
   */
  public int position;

  /**
   * TODO: Document me!
   */
  RouteSegment route;

  /**
   * TODO: Document me!
   */
  int travelTime = 0;

  /**
   * TODO: Document me!
   */
  public Car(Simulation simulation, String name, RouteSegment route) {
    this.simulation = simulation;
    this.name = name;
    this.route = route.next;
    road = route.crossroads.getRoadTo(route.next.crossroads);
    position = 0;
    road.occupy(0);
  }

  /**
   * TODO: Document me!
   */
  public void update() {
    travelTime++;
    if (position < road.getLength() - 1) {
      if (road.isFree(position + 1)) {
        road.leave(position);
        road.occupy(++position);
      }
    } else if (route.next == null) {
      road.leave(position);
      simulation.removeCar(this);
    } else if (route.crossroads.getRoadTo(route.next.crossroads).isFree(0)) {
      road.leave(position);
      road = route.crossroads.getRoadTo(route.next.crossroads);
      road.occupy(position = 0);
      route = route.next;
    }
  }

  public String reportStatus() {
    return name + " is on road `" + road.start.name + " -> " + road.end.name + "` at position " + position;
  }
}
