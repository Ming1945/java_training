package de.uni_hannover.sim.exemplary_solution.model;

/**
 * TODO: Document me!
 */
public class Road {

  /**
   * TODO: Document me!
   */
  public final Crossroads start;

  /**
   * TODO: Document me!
   */
  public final Crossroads end;

  /**
   * TODO: Document me!
   */
  final boolean[] fields;

  /**
   * TODO: Document me!
   */
  public Road(Crossroads start, Crossroads end, int length) {
    fields = new boolean[length];

    this.start = start;
    this.end = end;
    start.addRoad(this);
    end.addRoad(this);
  }

  // If you did a good job with the class doc comment, then the purpose, meaning
  // and signature of this method should be self-explanatory and it doesn't need
  // its own doc comment.
  public int getLength() {
    return fields.length;
  }

  /**
   * TODO: Document me!
   */
  public void occupy(int position) {
    if (fields[position]) {
      // This should never happen, because the car has to check if a position is free
      // before occupying it. This is a programming error on our part. Abort!
      // Dividing by zero is a veeery hacky way to halt the program. We'll learn
      // better ways to do this.
      System.out.println(1 / 0);
    }
    fields[position] = true;
  }

  /**
   * TODO: Document me!
   */
  public void leave(int position) {
    if (!fields[position]) {
      // See above.
      System.out.println(1 / 0);
    }
    fields[position] = false;
  }

  /**
   * TODO: Document me!
   */
  public boolean isFree(int position) {
    return !fields[position];
  }
}
