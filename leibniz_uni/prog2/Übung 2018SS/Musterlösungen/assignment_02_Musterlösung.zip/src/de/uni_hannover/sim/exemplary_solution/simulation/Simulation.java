package de.uni_hannover.sim.exemplary_solution.simulation;

import de.uni_hannover.sim.exemplary_solution.model.*;

/**
 * TODO: Document me!
 */
public class Simulation {
  protected static final int MAX_CARS = 10;

  /**
   * TODO: Document me!
   */
  protected final Car[] cars;

  /**
   * TODO: Document me!
   */
  protected final Crossroads[] crossroads;

  /**
   * TODO: Document me!
   */
  public Simulation() {
    cars = new Car[MAX_CARS];

    crossroads = new Crossroads[5];
    crossroads[0] = new Crossroads("A");
    crossroads[1] = new Crossroads("B");
    crossroads[2] = new Crossroads("C");
    crossroads[3] = new Crossroads("D");
    crossroads[4] = new Crossroads("E");

    new Road(crossroads[0], crossroads[2], 7);
    new Road(crossroads[1], crossroads[2], 4);
    new Road(crossroads[2], crossroads[3], 5);
    new Road(crossroads[2], crossroads[4], 3);
  }

  /**
   * TODO: Document me!
   */
  public void addCar(Car car) {
    for (int i = 0; i < cars.length; i++) {
      if (cars[i] == null) {
        cars[i] = car;
        return;
      }
    }
  }

  /**
   * TODO: Document me!
   */
  public void removeCar(Car car) {
    for (int i = 0; i < cars.length; i++) {
      if (cars[i] == car) {
        cars[i] = null;
        return;
      }
    }
  }

  /**
   * TODO: Document me!
   */
  public void run(final int iterations) {
    for (int elapsedTime = 0; elapsedTime < iterations; elapsedTime++) {
      for (int i = 0; i < cars.length; i++) {
        if (cars[i] != null) {
          cars[i].update();
        }
      }

      createCars(elapsedTime);

      System.out.println("t = " + elapsedTime);
      for (int i = 0; i < cars.length; i++) {
        if (cars[i] != null) {
          System.out.println("  " + cars[i].reportStatus());
        }
      }
      System.out.println("----");
    }
  }

  /**
   * TODO: Document me!
   */
  void createCars(int time) {
    if (time == 0) {
      addCar(new Car(this, "car 1",
          new RouteSegment(crossroads[0], new RouteSegment(crossroads[2], new RouteSegment(crossroads[4])))));
    } else if (time == 1) {
      addCar(new Car(this, "car 2",
          new RouteSegment(crossroads[0], new RouteSegment(crossroads[2], new RouteSegment(crossroads[3])))));
    } else if (time == 3) {
      addCar(new Car(this, "car 3",
          new RouteSegment(crossroads[1], new RouteSegment(crossroads[2], new RouteSegment(crossroads[4])))));
    }
  }
}
