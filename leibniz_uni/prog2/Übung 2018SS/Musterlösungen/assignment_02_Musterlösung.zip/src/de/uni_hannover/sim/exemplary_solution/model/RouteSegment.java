package de.uni_hannover.sim.exemplary_solution.model;

public class RouteSegment {
  final Crossroads crossroads;
  final RouteSegment next;

  public RouteSegment(Crossroads crossroads, RouteSegment next) {
    this.crossroads = crossroads;
    this.next = next;
  }

  public RouteSegment(Crossroads crossroads) {
    this(crossroads, null);
  }
}
