package de.uni_hannover.sim.exemplary_solution.application.cli;

import de.uni_hannover.sim.exemplary_solution.simulation.Simulation;

public class Main {
  protected static final int SIMULATION_DURATION = 15;

  public static void main(String[] args) {
    final Simulation simulation = new Simulation();
    simulation.run(SIMULATION_DURATION);
  }
}
