package de.uni_hannover.sim.exemplary_solution.model;

/**
 * TODO: Document me!
 */
public class Crossroads {
  static final int STREETS_PER_CROSSROAD = 4;

  public final String name;

  /**
   * TODO: Document me!
   */
  final Road[] startingRoads = new Road[STREETS_PER_CROSSROAD];

  /**
   * TODO: Document me!
   */
  final Road[] endingRoads = new Road[STREETS_PER_CROSSROAD];

  public Crossroads(String name) {
    this.name = name;
  }

  /**
   * Helper method used by the Road constructor to set up the mutual reference.
   */
  void addRoad(Road road) {
    Road[] roads = null;
    if (road.start == this) {
      roads = startingRoads;
    } else if (road.end == this) {
      roads = endingRoads;
    }

    for (int i = 0; i < roads.length; i++) {
      if (roads[i] == null) {
        roads[i] = road;
        return;
      }
    }
  }

  /**
   * TODO: Document me!
   */
  public Road getRoadTo(Crossroads other) {
    for (int i = 0; i < startingRoads.length; i++) {
      if (startingRoads[i].end == other) {
        return startingRoads[i];
      }
    }
    return null;
  }
}
