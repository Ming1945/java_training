package de.uni_hannover.sim.exemplary_solution.model;

import de.uni_hannover.sim.exemplary_solution.simulation.Simulation;

/**
 * Represents a crossroads where crossing is controlled by a traffic light. The
 * traffic light has a number of phases; Only roads with
 * {@code road.phase == this.currentGreenlightPhase} are greenlighted.
 *
 * This traffic light switches phases after a fixed amount of time passed.
 */
public class TimerControlledTrafficLightCrossroads extends Crossroads {
  /**
   * The duration (in time steps) of the individual greenlight phases.
   */
  protected final int[] greenlightDurations;

  /**
   * The greenlight phase this traffic light is currently in.
   */
  protected int currentGreenlightPase;

  /**
   * The remaining time steps until this traffic light switches into the next
   * phase.
   */
  protected int remainingGreenlightDuration;

  /**
   * Sets the current greenlight phase to phase 0, remaining time to the maximum
   * time of phase 0, and adds this actor to the simulation.
   */
  public TimerControlledTrafficLightCrossroads(Simulation simulation, String name, int[] greenlightDurations) {
    super(simulation, name);
    this.greenlightDurations = greenlightDurations;
    for (int i = 0; i < greenlightDurations.length; i++) {
      assert greenlightDurations[i] > 0 : "Each greenlight phase must be at least 1 unit of time long";
    }
    currentGreenlightPase = 0;
    remainingGreenlightDuration = greenlightDurations[0];
  }

  /**
   * Returns the number of greenlight phases.
   */
  public int getGreenlightPhaseCount() {
    return greenlightDurations.length;
  }

  /**
   * Returns {@code true} if the road is assigned to the current greenlight phase.
   */
  @Override
  public boolean isGreenlighted(Road road) {
    return super.isGreenlighted(road) && road.greenlightPase == currentGreenlightPase;
  }

  /**
   * Reduces the remaining time of the current phase by 1. Switches into the next
   * phase if the time reaches 0.
   */
  @Override
  public void update() {
    if (--remainingGreenlightDuration == 0) {
      currentGreenlightPase = (currentGreenlightPase + 1) % greenlightDurations.length;
      remainingGreenlightDuration = greenlightDurations[currentGreenlightPase];
    }
  }

  @Override
  public String reportStatus() {
    return "Traffic light " + name + " is in greenlight phase " + currentGreenlightPase + " for another "
        + remainingGreenlightDuration + " units of time";
  }
}
