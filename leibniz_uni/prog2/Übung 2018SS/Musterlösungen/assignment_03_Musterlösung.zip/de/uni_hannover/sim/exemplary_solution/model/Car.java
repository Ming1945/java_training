package de.uni_hannover.sim.exemplary_solution.model;

import de.uni_hannover.sim.exemplary_solution.simulation.Simulation;

/**
 * A car has the objective to drive through the road system along its
 * {@code route}. It occupies a single position on a street and can move one
 * position forward per time step. When it arrives at its location, it removes
 * itself from the simulation.
 */
public class Car extends Actor {
  /**
   * The road this car is currently on.
   */
  public Road road;

  /**
   * The position in {@code road} this car currently occupies.
   */
  public int position;

  /**
   * The remaining crossroads this car has to pass to arrive at its destination,
   * in the correct order.
   */
  RouteSegment route;

  /**
   * The number of time steps this car has been in the system.
   */
  int travelTime = 0;

  /**
   * Puts the car on position 0 of the first road of {@code route}, and adds this
   * car to {@code simulation}.
   */
  public Car(Simulation simulation, String name, RouteSegment route) {
    super(simulation, name);
    this.route = route.next;
    road = route.crossroads.getRoadTo(route.next.crossroads);
    position = 0;
    road.occupy(0);
  }

  /**
   * Tries to move the car one step forward on its route, in the following order:
   * <ol>
   * <li>If the car is not at the end of the road, move one position forward on
   * the current road.</li>
   * <li>If the crossroads in front of the car is the final destination of the
   * route, leave the current road and remove the car from the simulation.</li>
   * <li>The car is in front of an intermediate crossroads; leave the current
   * road, and move to position 0 of the road that leads to the next intermediate
   * crossroads in the route.</li>
   * </ol>
   * The car will never move onto a position on a road that is already occupied by
   * another car, neither will it cross a traffic light while its road is not
   * greenlighted.
   */
  public void update() {
    travelTime++;
    if (position < road.getLength() - 1) {
      if (road.isFree(position + 1)) {
        road.leave(position);
        road.occupy(++position);
      }
    } else if (route.next == null) {
      road.leave(position);
      simulation.removeActor(this);
    } else if (route.crossroads.getRoadTo(route.next.crossroads).isFree(0) && route.crossroads.isGreenlighted(road)) {
      road.leave(position);
      road = route.crossroads.getRoadTo(route.next.crossroads);
      road.occupy(position = 0);
      route = route.next;
    }
  }

  /**
   * Reports the name, current road, and current position.
   */
  public String reportStatus() {
    return name + " is on road `" + road.start.name + " -> " + road.end.name + "` at position " + position;
  }
}
