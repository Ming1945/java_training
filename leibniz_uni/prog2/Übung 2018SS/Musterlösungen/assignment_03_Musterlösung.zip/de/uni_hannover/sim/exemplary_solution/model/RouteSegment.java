package de.uni_hannover.sim.exemplary_solution.model;

/**
 * A <a href="https://en.wikipedia.org/wiki/Linked_list">linked list</a> that
 * represents a route that a car takes through the road system. Each
 * {@code RouteSegment} object stores a single intermediate destination, and a
 * reference to the next segment.
 *
 * The first crossroads in a route is the starting point of the car; The car
 * spawns on position 0 of the road that connects the first two segments. The
 * last segment represents the final destination of the car. The car arrives at
 * the destination if it stands on the last position of the road that ends at
 * that crossroad.
 *
 * RouteSegment objects are immutable, so they can be reused and shared between
 * objects without risk.
 */
public class RouteSegment {
  final Crossroads crossroads;
  final RouteSegment next;

  public RouteSegment(Crossroads crossroads, RouteSegment next) {
    this.crossroads = crossroads;
    this.next = next;
  }

  public RouteSegment(Crossroads crossroads) {
    this(crossroads, null);
  }
}
