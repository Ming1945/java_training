package de.uni_hannover.sim.exemplary_solution.model;

import de.uni_hannover.sim.exemplary_solution.simulation.Simulation;

/**
 * Represents a road intersection. Can be queried for incoming and outgoing
 * roads.
 */
public abstract class Crossroads extends Actor {
  /**
   * The maximum number of starting or ending roads at a single crossroads.
   */
  static final int STREETS_PER_CROSSROAD = 4;

  /**
   * All roads a car can take to get from this crossroads to somewhere else.
   */
  final Road[] startingRoads = new Road[STREETS_PER_CROSSROAD];

  /**
   * All roads that a car can take to arrive at this crossroads.
   */
  final Road[] endingRoads = new Road[STREETS_PER_CROSSROAD];

  public Crossroads(Simulation simulation, String name) {
    super(simulation, name);
  }

  /**
   * Helper method used by the Road constructor to set up the mutual reference.
   */
  void addRoad(Road road) {
    Road[] roads = null;
    if (road.start == this) {
      roads = startingRoads;
    } else if (road.end == this) {
      roads = endingRoads;
    }

    for (int i = 0; i < roads.length; i++) {
      if (roads[i] == null) {
        roads[i] = road;
        return;
      }
    }
  }

  /**
   * Returns the Road that leads from this to other.
   *
   * @return The road object starting at {@code this} and ending at {@code other},
   *         or {@code null} if no such road exists.
   */
  public Road getRoadTo(Crossroads other) {
    for (int i = 0; i < startingRoads.length; i++) {
      if (startingRoads[i].end == other) {
        return startingRoads[i];
      }
    }
    return null;
  }

  /**
   * This is an extension point for traffic light child classes, which can
   * override this method to communicate the current greenlight phase to roads and
   * cars.
   *
   * If this method returns {@code true} for a road, that road is currently
   * greenlighted by the traffic light controls of this crossroads and cars on
   * that road may cross this crossroads. For crossroads that are not controlled
   * by a traffic light, this method always returns {@code true}.
   *
   * @return {@code true}
   */
  public boolean isGreenlighted(Road road) {
    return true;
  }
}
