package de.uni_hannover.sim.exemplary_solution.simulation;

import java.util.Random;
import de.uni_hannover.sim.exemplary_solution.model.*;

/**
 * An object of type simulation stores a model of the simulated world, as well
 * as references to all {@code Actor}s. Instantiating a simulation will
 * initialize it with a road system. You can then call {@code update} on it to
 * advance its simulated time.
 */
public class Simulation {
  /**
   * The maximum number of actors that are expected to ever be in the simulation
   * simultaneously. Any more actors beyond this number will be silently
   * discarded.
   */
  protected static final int MAX_ACTORS = 100;

  /**
   * The random number generator that is shared across all actors of this
   * simulation.
   */
  public final Random rng;

  /**
   * A list of all actors that are currently active in the system. May contain
   * null indexes.
   */
  protected final Actor[] actors;

  /**
   * Initializes this simulation object with the fixed road system:
   *
   * <ul>
   * <li>{@code WorldBoundary} <i>A</i> with a spawn probability of 20%.</li>
   * <li>{@code WorldBoundary} <i>B</i> with a spawn probability of 30%.</li>
   * <li>{@code TimerControlledTrafficLightCrossroads} <i>C</i> with two
   * greenlight phases, each with a duration of 4 time steps.</li>
   * <li>{@code WorldBoundary} <i>D</i> with a spawn probability of 0%.</li>
   * <li>{@code WorldBoundary} <i>E</i> with a spawn probability of 0%.</li>
   * <li>A road from <i>A</i> to <i>C</i> with length 7 that is greenlighted on
   * phase 0.</li>
   * <li>A road from <i>B</i> to <i>C</i> with length 4 that is greenlighted on
   * phase 1.</li>
   * <li>A road from <i>C</i> to <i>D</i> with length 5.</li>
   * <li>A road from <i>C</i> to <i>E</i> with length 3.</li>
   * </ul>
   */
  public Simulation(Random rng) {
    this.rng = rng;
    actors = new Actor[MAX_ACTORS];

    WorldBoundary a = new WorldBoundary(this, "A", 0.2, 2);
    WorldBoundary b = new WorldBoundary(this, "B", 0.3, 2);
    Crossroads c = new TimerControlledTrafficLightCrossroads(this, "C", new int[] { 4, 4 });
    WorldBoundary d = new WorldBoundary(this, "D", 0.0, 0);
    WorldBoundary e = new WorldBoundary(this, "E", 0.0, 0);

    new Road(a, c, 7, 0);
    new Road(b, c, 4, 1);
    new Road(c, d, 5);
    new Road(c, e, 3);

    a.addRoute(new RouteSegment(a, new RouteSegment(c, new RouteSegment(d))));
    a.addRoute(new RouteSegment(a, new RouteSegment(c, new RouteSegment(e))));
    b.addRoute(new RouteSegment(b, new RouteSegment(c, new RouteSegment(d))));
    b.addRoute(new RouteSegment(b, new RouteSegment(c, new RouteSegment(e))));
  }

  /**
   * Advances the simulation time by {@code iterations} time steps, and reports
   * the current status of all actors in each step. This method may be called
   * multiple times on the same simulation object.
   */
  public void run(final int iterations) {
    for (int elapsedTime = 0; elapsedTime < iterations; elapsedTime++) {
      for (int i = 0; i < actors.length; i++) {
        if (actors[i] != null) {
          actors[i].update();
        }
      }

      System.out.println("t = " + elapsedTime);
      for (int i = 0; i < actors.length; i++) {
        if (actors[i] != null) {
          System.out.println("  " + actors[i].reportStatus());
        }
      }
      System.out.println("----");
    }
  }

  /**
   * Registers {@code actor} as an active actor in the simulation. When this
   * method is called during a {@code Simulation.run} iteration, it is unspecified
   * whether the actor will be updated in the current iteration or not.
   *
   * If {@code MAX_ACTORS} are already in this simulation, this method will
   * silently fail and <b>not</b> register {@code actor}. TODO: Change this as
   * soon as we know what exceptions are!
   *
   * This method may only be called by the {@code Actor} constructor!
   */
  public void addActor(Actor actor) {
    for (int i = 0; i < actors.length; i++) {
      if (actors[i] == null) {
        actors[i] = actor;
        return;
      }
    }
  }

  /**
   * Removes {@code Actor} from the list of active actors. It will not be updated
   * anymore.
   */
  public void removeActor(Actor actor) {
    for (int i = 0; i < actors.length; i++) {
      if (actors[i] == actor) {
        actors[i] = null;
        return;
      }
    }
  }
}
