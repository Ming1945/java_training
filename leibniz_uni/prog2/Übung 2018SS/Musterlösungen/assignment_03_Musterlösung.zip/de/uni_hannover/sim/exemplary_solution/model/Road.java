package de.uni_hannover.sim.exemplary_solution.model;

/**
 * A road connects two crossroads. Cars can drive on it, but only in one
 * direction: From {@code start} to {@code end}. If you need to drive in the
 * other direction, add a separate road object where start and end are switched.
 *
 * A road consists of a number of slots. Each slot has place for one car. Cars
 * can communicate their current position between each other by occupying slots
 * on the road; if another car is on the same road, it can avoid a collision by
 * checking whether the desired slot is free.
 */
public class Road {
  /**
   * The starting point of this road.
   */
  public final Crossroads start;

  /**
   * The destination of this road.
   */
  public final Crossroads end;

  /**
   * The slots on this road. {@code true} means the slot is currently occupied.
   */
  final boolean[] slots;

  /**
   * If {@code end} is a traffic light, and its current greenlight phase equals
   * this value, then this road is greenlighted.
   */
  final int greenlightPase;

  /**
   * Initializes a road that does not lead to a traffic light crossroads.
   */
  public Road(Crossroads start, Crossroads end, int length) {
    this(start, end, length, -1);
  }

  /**
   * Initialies a road whose {@code end} is a traffic light. This road is
   * greenlighted as long as {@code end} is in the same phase as
   * {@code greenlightPhase}.
   */
  public Road(Crossroads start, Crossroads end, int length, int greenlightPase) {
    slots = new boolean[length];

    this.start = start;
    this.end = end;
    start.addRoad(this);
    end.addRoad(this);

    assert greenlightPase == -1
        || end instanceof TimerControlledTrafficLightCrossroads : "Can't assign a greenlight phase to a road "
            + "if it doesn't end at a traffic light";
    this.greenlightPase = greenlightPase;
  }

  /**
   * Returns the number of slots on this road.
   */
  public int getLength() {
    return slots.length;
  }

  /**
   * Marks {@code slot} as occupied by a car. Fails if the position is already
   * occupied.
   */
  public void occupy(int slot) {
    assert !slots[slot] : "Already occupied";
    slots[slot] = true;
  }

  /**
   * Marks {@code slot} as no longer occupied. Fails if the position was already
   * free before.
   */
  public void leave(int slot) {
    assert slots[slot] : "Already free";
    slots[slot] = false;
  }

  /**
   * Indicates whether {@code slot} is free or occupied.
   *
   * @return {@code true} if the slot is free, {@code false} if the slot is
   *         occupied.
   */
  public boolean isFree(int slot) {
    return !slots[slot];
  }
}
