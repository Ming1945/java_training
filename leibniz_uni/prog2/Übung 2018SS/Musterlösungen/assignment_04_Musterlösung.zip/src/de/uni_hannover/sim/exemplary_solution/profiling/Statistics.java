package de.uni_hannover.sim.exemplary_solution.profiling;

import java.util.*;

public class Statistics {

  public static double calculateMin(double[] data) {
    return data[0];
  }

  public static double calculateMax(double[] data) {
    return data[data.length - 1];
  }

  public static double calculateMean(double[] data) {
    double sum = 0;
    for (int i = 0; i < data.length; i++) {
      sum += data[i];
    }
    return sum / data.length;
  }

  public static double calculateMedian(double[] data) {
    Arrays.sort(data);
    return data[(data.length - 1) / 2];
  }

  public static double calculateStandardDeviation(double[] data) {
    double sum = 0;
    double mean = calculateMean(data);
    for (int i = 0; i < data.length; i++) {
      sum += Math.pow(data[i] - mean, 2);
    }
    return Math.sqrt(sum / data.length);
  }

  public static double calculateRange(double[] data) {
    return calculateMax(data) - calculateMin(data);
  }

  public static double calculateUpperQuartile(double[] data) {
    Arrays.sort(data);
    return data[(data.length - 1) * 3 / 4];
  }

  public static double calculateLowerQuartile(double[] data) {
    Arrays.sort(data);
    return data[(data.length - 1) / 4];
  }
}
