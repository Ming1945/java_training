package de.uni_hannover.sim.exemplary_solution.application.cli;

import java.util.Random;

import de.uni_hannover.sim.exemplary_solution.simulation.Simulation;

public class Main {
  protected static final int SIMULATION_DURATION = 15;

  static final void printHelpTextAndExit(int statusCode) {
    System.out.println("traffic simulation");
    System.out.println("==================");
    System.out.println();
    System.out.println("usage:");
    System.out.println("  java de.uni_hannover.sim.exemplary_solution.application.cli.Main [options]");
    System.out.println();
    System.out.println("Options:");
    System.out.println("  -help          Prints this text and exits");
    System.out.println("  -seed <n>      Sets the seed of the random number generator to the specified");
    System.out.println("                 value. By default, the seed is chosen randomly");
    System.out
        .println("  -duration <n>  Executes the simulation for n time steps. Default value is " + SIMULATION_DURATION);
    System.out.println("  -inspect <name1, ...>");
    System.out.println("                 Prints the current status of the object with the specified");
    System.out.println("                 names every time step, and the mean values at the end");
    System.out.println("-profile-cars    Prints the status of all cars every time step, and their");
    System.out.println("                 combined mean at the end");
    System.exit(statusCode);
  }

  public static void main(String[] args) {
    Random rng = new Random();
    int duration = SIMULATION_DURATION;
    String[] dataSourceNames = new String[Simulation.MAX_DATA_SOURCES];
    boolean profileCars = false;

    for (int i = 0; i < args.length; i++) {
      if (args[i].equals("-seed")) {
        rng = new Random(Integer.parseInt(args[++i]));
      } else if (args[i].equals("-duration")) {
        duration = Integer.parseInt(args[++i]);
      } else if (args[i].equals("-inspect")) {
        String allNames = args[++i];
        int nameIndex = 0;
        int nameStart = 0;
        while (nameStart < allNames.length()) {
          int nameEnd = allNames.indexOf(',', nameStart);
          if (nameEnd == -1)
            nameEnd = allNames.length();
          dataSourceNames[nameIndex++] = allNames.substring(nameStart, nameEnd);
          nameStart = nameEnd + 1;
        }
      } else if (args[i].equals("-profile-cars")) {
        profileCars = true;
      } else if (args[i].equals("-help")) {
        printHelpTextAndExit(0);
      } else {
        printHelpTextAndExit(1);
      }
    }

    final Simulation simulation = new Simulation(rng, dataSourceNames, profileCars);
    simulation.run(duration);
  }
}
