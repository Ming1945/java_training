package de.uni_hannover.sim.exemplary_solution.model;

import de.uni_hannover.sim.exemplary_solution.simulation.Simulation;

/**
 * An actor is a simulation object with intrinsic behaviour: Instead of waiting
 * for external stimuli (method calls), it acts on its own. This is done through
 * the {@code update} method, which is called by {@code Simulation.run} on all
 * actors once for every simulated time step.
 */
public abstract class Actor {
  /**
   * A reference to the environment in which this actor operates.
   */
  public final Simulation simulation;

  /**
   * A name that can be used for profiling or debugging. Should be unique for
   * every actor.
   */
  public final String name;

  /**
   * Registers this actor in the {@code Simulation} as an active actor.
   */
  public Actor(Simulation simulation, String name) {
    this.simulation = simulation;
    this.name = name;
    simulation.addActor(this);
  }

  /**
   * This method must be overridden by subclasses to implement its behaviour.
   */
  public abstract void update();
}
